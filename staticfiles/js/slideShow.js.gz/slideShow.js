function slideShow() {
    var elem = document.getElementsByClassName("slider-card");
    
    for(var i; i < elem.length; i++) {
        elem[0].style.marginLeft = "50";
    }
}
